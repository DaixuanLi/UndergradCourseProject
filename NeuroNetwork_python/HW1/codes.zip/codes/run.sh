python3 run_mlp.py
python3 run_mlp_2.py
python3 run_mlp_3.py
python3 run_mlp_4.py
python3 run_mlp_5.py
python3 run_mlp_6.py
python3 run_mlp_7.py
python3 run_mlp_8.py
